# Merge Requests integrated in this release

## CI

* <details><summary>Update dependency renovate-bot/renovate-runner to v19.94.0</summary>

  * Update dependency renovate-bot/renovate-runner to v19.41.2 [!71](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/71) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.49.2 [!72](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/72) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.56.1 [!74](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/74) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.60.0 [!75](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/75) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.64.0 [!76](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/76) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.77.0 [!79](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/79) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.84.1 [!82](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/82) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.94.0 [!86](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/86) ~"renovate"
</details>

* <details><summary>Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.36</summary>

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.32 [!73](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/73) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.33 [!78](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/78) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.34 [!84](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/84) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.35 [!85](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/85) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.36 [!88](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/88) ~"renovate"
</details>

* Update quay.io/helmpack/chart-testing Docker tag to v3.12.0 [!80](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/80) ~"renovate"
* Update dependency to-be-continuous/gitleaks to v2.7.0 [!89](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/89) ~"renovate"

## Other

* canonical-k8s: add CK8S controlplane/configtemplate mappings [!87](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/87) ~"ck8s"

## Contributors

[Adrian Vladu](https://gitlab.com/ader1990)

# Merge Requests integrated in this release

## CI

* Update dependency to-be-continuous/gitleaks to v2.7.1 [!103](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/103) ~"renovate"
* <details><summary>Update dependency renovate-bot/renovate-runner to v22</summary>

  * Update dependency renovate-bot/renovate-runner to v21 [!107](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/107) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v22 [!109](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/109) ~"renovate"
</details>

* Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.40 [!110](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/110) ~"renovate"

## Other

* Add named template to ease adding specific resources in apiVersions from dependent Helm Chart [!99](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/99) 
* Move getMatchingMachineForBmh into sylva-library to be available from sylva-core [!108](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/108) 

## Contributors

[Arnaud Bouts](https://gitlab.com/stoub), [Cristian Manda](https://gitlab.com/cristian.manda)
